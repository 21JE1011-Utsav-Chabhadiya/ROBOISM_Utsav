def isPrime(num):
    for i in range(1,num):
        if(i == 1 or i == 2):
            print(i,end=" ")
        else:
            ans = True
            for j in range(2,i):
                
                if(i%j == 0):
                    ans = False
                    break
            if(ans):
                print(i,end=" ")
                
            
        

print("Prime Number Below 15")
isPrime(15)