def sum(str):
    
    ans = 0
    for i in str:
        if(i.isdigit()) :
            ans +=int(i)
    return ans

print('Test : "h20 15 wa73r" ')
print("Sum of Digits in test case  = ",sum("h20 15 wa73r"))
