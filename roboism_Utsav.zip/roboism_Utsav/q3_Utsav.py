def calc(num1,operation,num2):
    
    if operation =='+':
        return num1+num2
    elif operation =='-':
        return num1-num2
    elif operation =='*':
        return num1*num2
    elif operation =='/':
        return num1/num2
    else :
        print("Wrong Operator")
print('Test case 1: 4*6')
print('output ',calc(4,'*',6))
print('Test case 2: 4-6')
print('output ',calc(4,'-',6))
print('Test case 3: 4/6')
print('output ',calc(4,'/',6))
print('Test case 4: 4+6')
print('output ',calc(4,'+',6))