from multiprocessing.connection import answer_challenge
import numpy as np
def duplicate(intarr):
    ans =[]
    for i in intarr:
        temp = intarr.count(i);
        if(temp>1):
            if(ans.count(i)==0):
                ans.append(i)
            
    return ans        
            
temp = np.arange(1,100)
temp = np.insert(temp,99,10)
temp = list (temp)
print(duplicate(temp))
