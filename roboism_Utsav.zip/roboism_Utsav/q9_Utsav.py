def ascStr(str):
    list = []
    for i in str:
        list.append(i)
        
    for i in range(len(list)):
        min = list[i]
        index = i
        for j in range(i+1,len(list)):
            if(list[j]<min):
                min = list[j]
                index = j
        list[index] = list[i]
        list[i] = min
        
    return ''.join(list)

print(ascStr("utsav"))
     