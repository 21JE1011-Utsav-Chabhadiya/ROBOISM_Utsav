def doubleString(str):
    
    ans = ''
    for i in str:
        ans = ans + i*2
    return ans 
print("Test case 1: now")
print('Output 1: ',doubleString('now'))
print("Test case 2: 123al")
print('Output 2: ',doubleString('123al'))
