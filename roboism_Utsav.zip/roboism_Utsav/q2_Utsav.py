def hidenum(number):
    try:
        int(number)
        length = len(number)
        last4 = number[-4:]
        number = "*"*(length-4)+ last4
        return number
    except:
        print("Incorrect Card Number")
    
    
    
print('\nTest Case : 1')
print("Input = 1234567890")
print('output ',hidenum("1234567890"))
print('\nTest Casse : 2')
print("Input = 123jkbsd32")
print('output ',hidenum("123jkbsd32"))