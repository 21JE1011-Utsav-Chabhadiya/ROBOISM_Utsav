def maxFreq(num):
    
    freq = 0
    for i in num:
        count = num.count(i)
        if count>freq:
            freq=count
            maxnum = i
    return maxnum


print('Input [5,5,1,9,0,2,5,1,7,9]')
print('Highest Frequency : ',maxFreq([5,5,1,9,0,2,5,1,7,9]))