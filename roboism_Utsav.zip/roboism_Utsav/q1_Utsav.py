
        
def asc_dsc(list,str):
    if(str == 'asc'):
        print("Ascending")
        list.sort()
        return list
    elif(str == 'desc'):
        print("Descending")
        list.sort(reverse = True)
        return list
    elif(str =='none'):
        print("None")
        return list
    
list=[1,5,8,0,-2]
print(asc_dsc(list,"none"))
print(asc_dsc(list,"desc"))
print(asc_dsc(list,"asc"))

