def SwapNumbers(num1,num2):
    temp = num1
    num1= (num1^num2)^num1
    num2 =(temp^num2)^num2
    
    return num1,num2



print("Input (90,15)")
print('Output ',SwapNumbers(90,15))

